-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 19 2012 г., 07:57
-- Версия сервера: 5.5.25a
-- Версия PHP: 5.3.15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `6.mb`
--

-- --------------------------------------------------------

--
-- Структура таблицы `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `admin`
--

INSERT INTO `admin` (`id`, `name`, `pass`) VALUES
(1, 'admin', '0c800f4444be6e3c0eaece64829409fc');

-- --------------------------------------------------------

--
-- Структура таблицы `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `link` varchar(255) NOT NULL,
  `tag` varchar(255) CHARACTER SET utf8 NOT NULL,
  `meta_d` varchar(255) CHARACTER SET utf8 NOT NULL,
  `meta_k` varchar(255) CHARACTER SET utf8 NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Дамп данных таблицы `content`
--

INSERT INTO `content` (`id`, `title`, `link`, `tag`, `meta_d`, `meta_k`, `content`, `date`, `time`) VALUES
(7, 'Captcha', 'captcha', 'Captcha', 'Captcha', 'Captcha', '       123123123 Captcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha CaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptchaCaptcha', '2012-08-18', '17:12:09'),
(8, 'Download', 'download', 'Download', 'Download', 'Download', '  downloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownloaddownload', '2012-08-14', '17:36:40'),
(10, 'Database', 'database', 'Database, Download', 'Data, Dowload', 'Data, Download', '   DarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabaseDarabase', '2012-08-15', '19:20:29');

-- --------------------------------------------------------

--
-- Структура таблицы `folio`
--

CREATE TABLE IF NOT EXISTS `folio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `dev_time` varchar(255) CHARACTER SET utf8 NOT NULL,
  `platform` varchar(255) CHARACTER SET utf8 NOT NULL,
  `link` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `img` tinytext CHARACTER SET utf8 NOT NULL,
  `img_s` tinytext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `folio`
--

INSERT INTO `folio` (`id`, `title`, `dev_time`, `platform`, `link`, `description`, `img`, `img_s`) VALUES
(1, '1', '2', '3', '4', '5', './file/B4UJN1aqL9.jpg', './file/B4UJN1aqL9_s.jpg'),
(2, 'Department of Obstetrics and Gynecology', '2 month', 'Wordpress', 'http://obgyn.mokamedianyc.com/', 'Hard first work with WP', './file/HwZRybXMes.png', './file/HwZRybXMes_s.png');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `name`) VALUES
(1, '67567'),
(2, 'ghjkghjk'),
(3, 'ghjkghjk'),
(4, 'sdfgsdfg'),
(5, 'sdfgsdfg'),
(6, 'sdfgsdfg'),
(7, 'sdfgsdfgdg'),
(8, 'sdfgsdfg'),
(9, 'sdfgsdfg'),
(10, 'sdfgsdfg'),
(11, 'sdfgsdfg'),
(12, 'sdfgsdfg444444444444'),
(13, 'asdasd'),
(14, '123'),
(15, 'fsdfsdf'),
(16, '111zcxdd'),
(17, 'a2224444'),
(18, '543');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
